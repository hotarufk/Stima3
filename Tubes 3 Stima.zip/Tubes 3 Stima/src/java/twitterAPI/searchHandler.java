package twitterAPI;



public class searchHandler {
public	String nama;
public	String tweet;
public	int jenistweet=0; //ini bisa dipake buat nandain dia masuk yang mana, kalo 0 = netral , 1= positif , 2 = negatif
public String URL; //ini nyimpen url dari tweet nya
}
